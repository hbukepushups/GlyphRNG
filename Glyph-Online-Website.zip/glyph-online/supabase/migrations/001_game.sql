-- Fresh project migration. Run ONCE using Supabase SQL Editor.
create extension if not exists pgcrypto with schema extensions;
revoke create on schema public from public, anon, authenticated;
create table public.glyph_rules (id int primary key default 1 check(id=1), version int not null default 1);
insert into public.glyph_rules default values;
create table public.glyph_letters (
 base text primary key, upper_glyph text not null, tier text not null, weight numeric not null,
 basic_accents text[] not null default '{}', rare_accents text[] not null default '{}', interface_ok boolean not null default false
);
insert into public.glyph_letters(base,upper_glyph,tier,weight,basic_accents,rare_accents,interface_ok) values
('e','E','Common',50,array['é','è','ê','ë'],array['ē','ė','ę'],false),
('t','T','Common',50,'{}','{}',false),
('a','A','Common',50,array['á','à','â','ä'],array['ā','ă','ą'],false),
('o','O','Common',50,array['ó','ò','ô','ö'],array['ō','ő','ơ'],false),
('i','I','Common',50,array['í','ì','î','ï'],array['ī','į','ĭ'],false),
('n','N','Uncommon',27,array['ñ'],array['ń','ň'],false),
('s','S','Uncommon',27,array['ś','š'],array['ş','ș'],false),
('r','R','Uncommon',27,array['ŕ'],array['ř','ŗ'],false),
('h','H','Uncommon',27,'{}','{}',false),
('d','D','Uncommon',27,'{}','{}',false),
('l','L','Rare',14,'{}','{}',false),
('u','U','Rare',14,array['ú','ù','û','ü'],array['ū','ů','ű'],false),
('c','C','Rare',14,array['ç','ć'],array['č','ĉ'],false),
('m','M','Rare',14,'{}','{}',false),
('f','F','Rare',14,'{}','{}',false),
('y','Y','Rare',14,array['ý','ÿ'],array['ŷ'],false),
('w','W','Epic',6,'{}','{}',false),('g','G','Epic',6,'{}','{}',false),
('p','P','Epic',6,'{}','{}',false),('b','B','Epic',6,'{}','{}',false),('v','V','Epic',6,'{}','{}',false),
('k','K','Legendary',2.7,'{}','{}',false),('x','X','Legendary',2.7,'{}','{}',false),
('q','Q','Legendary',2.7,'{}','{}',false),('j','J','Legendary',2.7,'{}','{}',false),('z','Z','Legendary',2.7,'{}','{}',false),
('æ','Æ','Mythic',.3,'{}','{}',false),('þ','Þ','Mythic',.3,'{}','{}',false),
('ð','Ð','Mythic',.3,'{}','{}',false),('ƿ','Ƿ','Mythic',.3,'{}','{}',false),('œ','Œ','Mythic',.3,'{}','{}',false),
('α','Α','Mythic',.3,'{}','{}',false),('δ','Δ','Mythic',.3,'{}','{}',true),
('β','Β','Mythic',.3,'{}','{}',false),('π','Π','Mythic',.3,'{}','{}',false),
('σ','Σ','Mythic',.3,'{}','{}',true),('ω','Ω','Mythic',.3,'{}','{}',true),
('ψ','Ψ','Mythic',.3,'{}','{}',false),('φ','Φ','Mythic',.3,'{}','{}',false),('ξ','Ξ','Mythic',.3,'{}','{}',false);
create table public.glyph_blocked_terms(term text primary key);
-- Editable baseline, NOT a guarantee against all abuse. Normalization catches separators and common leetspeak.
-- Allowed as requested: hell, damn, shit, ass (and their derivatives are not explicitly blocked).
insert into public.glyph_blocked_terms values ('fuck'),('bitch'),('cunt'),('cock'),('dick'),('pussy'),('whore'),('slut'),('nigger'),('nigga'),('faggot'),('retard'),('kike'),('chink'),('spic'),('tranny');
create table public.glyph_profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text not null, username_key text unique not null,
 avatar_path text, total_rolls bigint not null default 0, next_roll timestamptz not null default now(),
 bonus_ready boolean not null default false, banned boolean not null default false,
 created_at timestamptz not null default now()
);
create table public.glyph_items (
 id uuid primary key default extensions.gen_random_uuid(), owner_id uuid not null references public.glyph_profiles(id),
 original_owner uuid not null references public.glyph_profiles(id),
 base text not null references public.glyph_letters(base), glyph text not null, tier text not null,
 uppercase boolean not null, accent text not null, finish text not null, form text not null,
 variant text not null, probability numeric not null, actual_probability numeric not null,
 value numeric not null, roll_luck numeric not null, created_at timestamptz not null default now(),
 consumed boolean not null default false, escrow uuid
);
create index glyph_items_owner on public.glyph_items(owner_id) where not consumed;
create table public.glyph_rolls (
 id uuid primary key references public.glyph_items(id), user_id uuid not null references public.glyph_profiles(id),
 base text not null, variant text not null, tier text not null, finish text not null, form text not null,
 accent text not null, uppercase boolean not null, probability numeric not null, actual_probability numeric not null,
 created_at timestamptz not null default now()
);
create index glyph_rolls_user on public.glyph_rolls(user_id,base);
create table public.glyph_buffs (
 id uuid primary key default extensions.gen_random_uuid(), user_id uuid not null references public.glyph_profiles(id),
 recipe text not null, luck numeric not null, speed numeric not null, remaining int not null
);
create table public.glyph_recipes (
 id text primary key, name text not null, ingredients jsonb not null, luck numeric not null, speed numeric not null, rolls int not null
);
insert into public.glyph_recipes values
('starter','First Spark','[{"tier":"Rare"},{"tier":"Rare"},{"tier":"Rare"}]',1.15,1,20),
('quick','Quick Ink','[{"tier":"Epic"},{"tier":"Rare"},{"tier":"Uncommon"}]',1,.9,25),
('circle','Circle Engine','[{"base":"δ"},{"base":"π"},{"base":"σ"},{"finish":"silver"},{"accent":"basic"}]',1.5,.9,60),
('prism','Prismatic Drive','[{"base":"ω"},{"tier":"Mythic"},{"finish":"gold"},{"accent":"rare"}]',2,.8,80),
('interface','Interface Reactor','[{"form":"interface"},{"tier":"Mythic","finish":"silver"},{"finish":"platinum"},{"accent":"rare"}]',3,.7,120);
create table public.glyph_posts (
 id uuid primary key default extensions.gen_random_uuid(), user_id uuid not null references public.glyph_profiles(id),
 kind text not null check(kind in ('have','want')), item_id uuid references public.glyph_items(id),
 wanted_base text references public.glyph_letters(base), wanted_finish text, wanted_form text,
 status text not null default 'open', created_at timestamptz not null default now()
);
create table public.glyph_offers (
 id uuid primary key default extensions.gen_random_uuid(), post_id uuid not null references public.glyph_posts(id),
 user_id uuid not null references public.glyph_profiles(id), item_ids uuid[] not null, status text not null default 'open',
 created_at timestamptz not null default now()
);
create index glyph_offers_post on public.glyph_offers(post_id);
-- No client direct writes or table reads. All access goes through a narrow authenticated RPC.
do $$ declare t text; begin
 foreach t in array array['glyph_rules','glyph_letters','glyph_blocked_terms','glyph_profiles','glyph_items','glyph_rolls','glyph_buffs','glyph_recipes','glyph_posts','glyph_offers'] loop
 execute format('alter table public.%I enable row level security',t);
 execute format('revoke all on public.%I from anon, authenticated',t);
 end loop;
end $$;
create function public.glyph_rand() returns numeric language sql volatile set search_path=public,extensions,pg_temp as $$
 select (get_byte(b,0)::numeric*16777216+get_byte(b,1)::numeric*65536+get_byte(b,2)::numeric*256+get_byte(b,3)::numeric)/4294967296 from (select extensions.gen_random_bytes(4) b) s;
$$;
create function public.glyph_api(action text, args jsonb default '{}') returns jsonb
language plpgsql security definer set search_path=public,extensions,pg_temp as $$
declare
 uid uuid:=auth.uid(); p glyph_profiles%rowtype; lt glyph_letters%rowtype; it glyph_items%rowtype;
 po glyph_posts%rowtype; ofr glyph_offers%rowtype; rec glyph_recipes%rowtype;
 uname text; norm text; v text; g text; ac text; fi text; fo text; up boolean;
 luck numeric:=1; speed numeric:=1; denom numeric; prob numeric; actual numeric; tp numeric; ap numeric:=1; fp numeric:=1; ip numeric:=1;
 rollnum numeric; cursor_n numeric:=0; tiername text; tierweight numeric; numletters int;
 fresh boolean; id1 uuid; id2 uuid; ids uuid[]; selected uuid[]:='{}'; ing jsonb; obj jsonb; result jsonb;
 b record; count_n int; sortuid uuid; firstitem glyph_items%rowtype;
begin
 if uid is null then raise exception 'Please sign in first'; end if;
 if not exists(select 1 from auth.users where id=uid and email_confirmed_at is not null) then raise exception 'Verify your email first'; end if;
 -- Serialize all economy transactions, including multi-player trades. Deliberately conservative for a small launch.
 -- A single global lock avoids cross-player deadlocks. Replace with ordered per-player locks before large scale.
 perform pg_advisory_xact_lock(76124491);
 select * into p from glyph_profiles where id=uid for update;
 if p.banned then raise exception 'Account suspended'; end if;
 if action='setup' then
  uname:=args->>'username';
  if uname is null or uname !~ '^[A-Za-z0-9_/-]{3,20}$' then raise exception 'Username: 3–20 English letters, digits, -, _, or / only'; end if;
  norm:=regexp_replace(translate(lower(uname),'013457','oieast'),'[^a-z]','','g');
  if exists(select 1 from glyph_blocked_terms where position(term in norm)>0) then raise exception 'That username is not allowed'; end if;
  if p.id is not null then raise exception 'Username is already set'; end if;
  insert into glyph_profiles(id,username,username_key) values(uid,uname,lower(uname));
  return jsonb_build_object('ok',true);
 end if;
 if p.id is null and action<>'bootstrap' then raise exception 'Finish account setup first'; end if;
 if action='bootstrap' then
  return jsonb_build_object('profile',(select to_jsonb(x) from (select id,username,avatar_path,total_rolls,bonus_ready,next_roll from glyph_profiles where id=uid)x),
  'letters',(select jsonb_agg(to_jsonb(x) order by weight desc,base) from glyph_letters x),
  'recipes',(select jsonb_agg(to_jsonb(x) order by rolls) from glyph_recipes x),
  'buffs',coalesce((select jsonb_agg(to_jsonb(x)) from glyph_buffs x where user_id=uid and remaining>0),'[]'::jsonb),
  'inventory',coalesce((select jsonb_agg(to_jsonb(x) order by created_at desc) from glyph_items x where owner_id=uid and not consumed),'[]'::jsonb),
  'discoveries',coalesce((select jsonb_agg(distinct base) from glyph_rolls where user_id=uid),'[]'::jsonb),
  'variants',coalesce((select jsonb_agg(distinct variant) from glyph_rolls where user_id=uid),'[]'::jsonb));
 elsif action='roll' then
  if clock_timestamp()<p.next_roll then raise exception 'Cooldown active'; end if;
  for b in select * from glyph_buffs where user_id=uid and remaining>0 loop luck:=luck*b.luck;speed:=speed*b.speed;end loop;
  luck:=least(8,luck*(case when p.bonus_ready then 2 else 1 end)); speed:=greatest(.2,speed);
  denom:=77+23*luck;rollnum:=glyph_rand()*denom;
  for tiername,tierweight in select * from (values ('Common',50::numeric),('Uncommon',27::numeric),('Rare',14*luck),('Epic',6*luck),('Legendary',2.7*luck),('Mythic',.3*luck)) t(n,w) loop
   cursor_n:=cursor_n+tierweight;exit when rollnum<cursor_n;
  end loop;
  select count(*) into numletters from glyph_letters where tier=tiername;
  select * into lt from glyph_letters where tier=tiername order by base offset floor(glyph_rand()*numletters)::int limit 1;
  up:=glyph_rand()<.25; g:=lt.base;ac:='none';fo:='normal';fi:='normal';
  if cardinality(lt.basic_accents)>0 then
   rollnum:=glyph_rand();
   if rollnum<.001 then ac:='rare';g:=lt.rare_accents[1+floor(glyph_rand()*cardinality(lt.rare_accents))::int];ap:=.001/cardinality(lt.rare_accents);
   elsif rollnum<.011 then ac:='basic';g:=lt.basic_accents[1+floor(glyph_rand()*cardinality(lt.basic_accents))::int];ap:=.01/cardinality(lt.basic_accents);
   else ap:=.989;end if;
  end if;
  if up then g:=case when ac='none' then lt.upper_glyph else upper(g) end;end if;
  rollnum:=glyph_rand();
  if rollnum<.001 then fi:='platinum';fp:=.001;elsif rollnum<.005 then fi:='gold';fp:=.004;elsif rollnum<.025 then fi:='silver';fp:=.02;else fp:=.975;end if;
  if lt.interface_ok then if glyph_rand()<.0001 then fo:='interface';ip:=.0001;else ip:=.9999;end if;end if;
  prob:=(lt.weight/100/numletters)*(case when up then .25 else .75 end)*ap*fp*ip;
  actual:=(tierweight/denom/numletters)*(case when up then .25 else .75 end)*ap*fp*ip;
  v:=lt.base||'|'||g||'|'||(case when up then 'U' else 'L' end)||'|'||ac||'|'||fi||'|'||fo;
  fresh:=not exists(select 1 from glyph_rolls where user_id=uid and base=lt.base);
  insert into glyph_items(owner_id,original_owner,base,glyph,tier,uppercase,accent,finish,form,variant,probability,actual_probability,value,roll_luck)
   values(uid,uid,lt.base,g,tiername,up,ac,fi,fo,v,prob,actual,1/prob/100,luck) returning * into it;
  insert into glyph_rolls(id,user_id,base,variant,tier,finish,form,accent,uppercase,probability,actual_probability)
   values(it.id,uid,it.base,it.variant,it.tier,it.finish,it.form,it.accent,it.uppercase,prob,actual);
  update glyph_profiles set total_rolls=total_rolls+1,bonus_ready=((total_rolls+1)%10=0),next_roll=clock_timestamp()+make_interval(secs=>(5*speed)::double precision) where id=uid;
  update glyph_buffs set remaining=remaining-1 where user_id=uid and remaining>0;
  return jsonb_build_object('item',to_jsonb(it),'new_base',fresh,'luck',luck,'cooldown',5*speed,'bonus_used',p.bonus_ready);
 elsif action='stats' then
  select * into lt from glyph_letters where base=args->>'base';if not found then raise exception 'Unknown letter';end if;
  return jsonb_build_object('base',lt.base,'roll_count',(select count(*) from glyph_rolls where user_id=uid and base=lt.base),
   'owned_count',(select count(*) from glyph_items where owner_id=uid and base=lt.base and not consumed),
   'first_roll',(select to_jsonb(r) from glyph_rolls r where user_id=uid and base=lt.base order by created_at limit 1),
   'best_roll',(select to_jsonb(r) from glyph_rolls r where user_id=uid and base=lt.base order by probability limit 1),
   'variant_counts',coalesce((select jsonb_agg(to_jsonb(x)) from (select variant,count(*) from glyph_rolls where user_id=uid and base=lt.base group by variant)x),'[]'::jsonb));
 elsif action='avatar' then
  v:=args->>'path';if v<>uid::text||'/avatar.webp' then raise exception 'Invalid avatar path';end if;
  update glyph_profiles set avatar_path=v where id=uid;return '{"ok":true}';
 elsif action='craft' then
  select * into rec from glyph_recipes where id=args->>'recipe';if not found then raise exception 'Unknown recipe';end if;
  select array_agg(x::uuid) into ids from jsonb_array_elements_text(args->'items') x;
  if coalesce(cardinality(ids),0)<>jsonb_array_length(rec.ingredients) or cardinality(ids)<>(select count(distinct x) from unnest(ids)x) then raise exception 'Select one distinct item for each ingredient';end if;
  -- Ingredients are ordered: client explicitly reviews the exact consumed item IDs.
  count_n:=0;
  for ing in select * from jsonb_array_elements(rec.ingredients) loop
   count_n:=count_n+1;select * into it from glyph_items where id=ids[count_n] and owner_id=uid and not consumed and escrow is null for update;
   if not found or not(to_jsonb(it) @> ing) then raise exception 'Ingredient % does not match, is locked, or is no longer owned',count_n;end if;
  end loop;
  if (select count(*) from glyph_buffs where user_id=uid and remaining>0)>=12 then raise exception 'At most 12 active boosters';end if;
  update glyph_items set consumed=true where id=any(ids);
  insert into glyph_buffs(user_id,recipe,luck,speed,remaining) values(uid,rec.id,rec.luck,rec.speed,rec.rolls);
  return '{"ok":true}';
 elsif action='leaderboard' then
  return coalesce((select jsonb_agg(to_jsonb(x)) from (select profile_row.username,profile_row.avatar_path,coalesce(sum(i.value),0) value,profile_row.total_rolls from glyph_profiles profile_row left join glyph_items i on i.owner_id=profile_row.id and not i.consumed where not profile_row.banned group by profile_row.id order by value desc,profile_row.created_at limit 100)x),'[]'::jsonb);
 elsif action='market' then
  return jsonb_build_object('posts',coalesce((select jsonb_agg(to_jsonb(x)) from (select post_row.*,pr.username,to_jsonb(i) item from glyph_posts post_row join glyph_profiles pr on pr.id=post_row.user_id left join glyph_items i on i.id=post_row.item_id where post_row.status='open' order by (post_row.user_id=uid or exists(select 1 from glyph_offers z where z.post_id=post_row.id and z.user_id=uid and z.status='open')) desc, post_row.created_at desc limit 130)x),'[]'::jsonb),
   'offers',coalesce((select jsonb_agg(to_jsonb(x)) from (select o.*,pr.username,(select jsonb_agg(to_jsonb(i)) from glyph_items i where i.id=any(o.item_ids)) items from glyph_offers o join glyph_profiles pr on pr.id=o.user_id join glyph_posts post_row on post_row.id=o.post_id where o.status='open' and (o.user_id=uid or post_row.user_id=uid) order by o.created_at desc)x),'[]'::jsonb));
 elsif action='post' then
  if (select count(*) from glyph_posts where user_id=uid and status='open')>=10 then raise exception '10 open posts maximum';end if;
  if args->>'kind'='have' then
   select * into it from glyph_items where id=(args->>'item')::uuid and owner_id=uid and not consumed and escrow is null for update;
   if not found then raise exception 'Item unavailable';end if;
   insert into glyph_posts(user_id,kind,item_id) values(uid,'have',it.id) returning id into id1;
   update glyph_items set escrow=id1 where id=it.id;
  elsif args->>'kind'='want' then
   if not exists(select 1 from glyph_letters where base=args->>'base') then raise exception 'Unknown letter';end if;
   if coalesce(args->>'finish','any') not in ('any','normal','silver','gold','platinum') or coalesce(args->>'form','any') not in ('any','normal','interface') then raise exception 'Invalid filters';end if;
   insert into glyph_posts(user_id,kind,wanted_base,wanted_finish,wanted_form) values(uid,'want',args->>'base',coalesce(args->>'finish','any'),coalesce(args->>'form','any')) returning id into id1;
  else raise exception 'Invalid post type';end if;
  return jsonb_build_object('id',id1);
 elsif action='offer' then
  select * into po from glyph_posts where id=(args->>'post')::uuid and status='open' for update;
  if not found or po.user_id=uid then raise exception 'Post unavailable or belongs to you';end if;
  if (select count(*) from glyph_offers where user_id=uid and status='open')>=20 then raise exception '20 open offers maximum';end if;
  select array_agg(x::uuid) into ids from jsonb_array_elements_text(args->'items') x;
  if coalesce(cardinality(ids),0) not between 1 and 8 or cardinality(ids)<>(select count(distinct x) from unnest(ids)x) then raise exception 'Offer 1–8 distinct items';end if;
  if (select count(*) from glyph_items where id=any(ids) and owner_id=uid and not consumed and escrow is null)<>cardinality(ids) then raise exception 'One or more items unavailable';end if;
  if po.kind='want' and not exists(select 1 from glyph_items where id=any(ids) and base=po.wanted_base and (po.wanted_finish='any' or finish=po.wanted_finish) and (po.wanted_form='any' or form=po.wanted_form)) then raise exception 'Include the requested letter in your offer';end if;
  insert into glyph_offers(post_id,user_id,item_ids) values(po.id,uid,ids) returning id into id1;
  update glyph_items set escrow=id1 where id=any(ids);return jsonb_build_object('id',id1);
 elsif action in ('cancel_post','cancel_offer','reject','accept') then
  if action='cancel_post' then
   select * into po from glyph_posts where id=(args->>'post')::uuid and user_id=uid and status='open' for update;
   if not found then raise exception 'Post unavailable';end if;
  else
   select * into ofr from glyph_offers where id=(args->>'offer')::uuid and status='open' for update;
   if not found then raise exception 'Offer unavailable';end if;
   select * into po from glyph_posts where id=ofr.post_id and status='open' for update;
   if not found then raise exception 'Post closed';end if;
   if action='cancel_offer' then
    if ofr.user_id<>uid then raise exception 'Not your offer';end if;
   elsif po.user_id<>uid then raise exception 'Not your post';end if;
  end if;
  if action='cancel_post' then
   update glyph_posts set status='cancelled' where id=po.id;
   update glyph_items set escrow=null where escrow=po.id;
   update glyph_offers set status='cancelled' where post_id=po.id and status='open';
   update glyph_items set escrow=null where escrow in (select id from glyph_offers where post_id=po.id);
   return '{"ok":true}';
  elsif action in ('cancel_offer','reject') then
   update glyph_offers set status=case when action='reject' then 'rejected' else 'cancelled' end where id=ofr.id;
   update glyph_items set escrow=null where escrow=ofr.id;return '{"ok":true}';
  end if;
  if action='accept' then
   if exists(select 1 from glyph_profiles where id=ofr.user_id and banned) then raise exception 'Trader suspended';end if;
   if (select count(*) from glyph_items where id=any(ofr.item_ids) and owner_id=ofr.user_id and not consumed and escrow=ofr.id)<>cardinality(ofr.item_ids) then raise exception 'Offer no longer valid';end if;
   if po.kind='have' then
    select * into it from glyph_items where id=po.item_id and owner_id=uid and escrow=po.id and not consumed for update;
    if not found then raise exception 'Listed item unavailable';end if;
    update glyph_items set owner_id=ofr.user_id,escrow=null where id=it.id;
   else
    -- Wanted posts specify the request; owner chooses payment explicitly on acceptance.
    select array_agg(x::uuid) into ids from jsonb_array_elements_text(args->'payment') x;
    if coalesce(cardinality(ids),0) not between 1 and 8 or cardinality(ids)<>(select count(distinct x) from unnest(ids)x) then raise exception 'Choose 1–8 distinct payment items';end if;
    if (select count(*) from glyph_items where id=any(ids) and owner_id=uid and not consumed and escrow is null)<>cardinality(ids) then raise exception 'Payment items unavailable';end if;
    update glyph_items set owner_id=ofr.user_id where id=any(ids);
   end if;
   update glyph_items set owner_id=uid,escrow=null where id=any(ofr.item_ids);
   update glyph_offers set status='accepted' where id=ofr.id;
  end if;
  update glyph_items set escrow=null where escrow=po.id or escrow in (select id from glyph_offers where post_id=po.id and status='open');
  update glyph_offers set status='cancelled' where post_id=po.id and status='open';
  update glyph_posts set status=case when action='accept' then 'completed' else 'cancelled' end where id=po.id;
  return '{"ok":true}';
 else raise exception 'Unknown action';end if;
end $$;
revoke all on function public.glyph_rand() from public,anon,authenticated;
revoke all on function public.glyph_api(text,jsonb) from public,anon;
grant execute on function public.glyph_api(text,jsonb) to authenticated;
-- Avatar bucket: image-only, 2 MB. UI decodes and re-encodes images to WebP.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
 values('avatars','avatars',true,2097152,array['image/webp']) on conflict(id) do nothing;
create policy "glyph_avatar_insert" on storage.objects for insert to authenticated
 with check(bucket_id='avatars' and name=auth.uid()::text||'/avatar.webp');
create policy "glyph_avatar_update" on storage.objects for update to authenticated
 using(bucket_id='avatars' and name=auth.uid()::text||'/avatar.webp')
 with check(bucket_id='avatars' and name=auth.uid()::text||'/avatar.webp');
create policy "glyph_avatar_select_own" on storage.objects for select to authenticated
 using(bucket_id='avatars' and name=auth.uid()::text||'/avatar.webp');
create policy "glyph_avatar_delete" on storage.objects for delete to authenticated
 using(bucket_id='avatars' and name=auth.uid()::text||'/avatar.webp');
