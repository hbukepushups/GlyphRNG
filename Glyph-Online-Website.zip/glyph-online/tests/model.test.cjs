// Model/invariant tests, not a replacement for staging Postgres + browser tests.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const sql=fs.readFileSync(path.join(__dirname,'../supabase/migrations/001_game.sql'),'utf8');
const app=fs.readFileSync(path.join(__dirname,'../app.js'),'utf8');
const weights=[50,27,14,6,2.7,.3],sizes=[5,5,6,5,5,14];
const near=(a,b)=>assert(Math.abs(a-b)<1e-10,`${a} != ${b}`);
near(weights.reduce((a,b)=>a+b),100);
assert.equal(sizes.reduce((a,b)=>a+b),40);
near(.75+.25,1);near(.975+.02+.004+.001,1);near(.989+.01+.001,1);near(.9999+.0001,1);
for(const L of [1,1.15,2,4,8]){
 const d=77+23*L,ps=weights.map((w,i)=>w*(i<2?1:L)/d);near(ps.reduce((a,b)=>a+b),1);
 assert(ps.every(p=>p>0&&p<1));if(L>1)assert(ps[5]>.003);
}
for(let ti=0;ti<6;ti++)for(const accented of [false,true])for(const iface of [false,true]){
 let total=0;
 for(const c of [.75,.25])for(const f of [.975,.02,.004,.001])for(const a of accented?[.989,.01,.001]:[1])for(const i of iface?[.9999,.0001]:[1])total+=c*f*a*i;
 near(total,1);
 const p=weights[ti]/100/sizes[ti]*.75*.975*(accented?.989:1)*(iface?.9999:1);
 assert(p>0);near((1/p/100)*p,.01);
}
near((1/(1/14))/100,.14);
assert.equal(Math.min(8,3*3*2),8);assert.equal(Math.max(.2,.7**10)*5,1);
for(const n of [10,20,30,100])assert.equal(n%10===0,true);
assert(sql.includes("revoke all on function public.glyph_api(text,jsonb) from public,anon"));
assert(sql.includes("grant execute on function public.glyph_api(text,jsonb) to authenticated"));
assert(sql.includes('pg_advisory_xact_lock'));assert(sql.includes('email_confirmed_at is not null'));
assert(sql.includes('revoke create on schema public'));assert(sql.includes('extensions.gen_random_bytes(4)'));
assert(sql.includes("if action='cancel_post' then"));assert(sql.includes("elsif action in ('cancel_offer','reject') then"));
assert(sql.includes("value,roll_luck"));assert(sql.includes("1/prob/100,luck"));
assert(app.includes('res.new_base||'));assert(app.includes("$('stopNew').disabled=true"));
console.log('All probability-model and source-guardrail checks passed. Live Postgres/browser tests still required.');
